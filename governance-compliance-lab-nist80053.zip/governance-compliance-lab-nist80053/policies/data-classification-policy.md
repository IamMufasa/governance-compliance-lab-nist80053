# Data Classification Policy

Defines how organizational data is classified, labeled, and handled according to its sensitivity.