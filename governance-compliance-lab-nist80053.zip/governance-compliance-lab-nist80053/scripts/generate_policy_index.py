#!/usr/bin/env python3
import os

policy_dir = '../policies'
for file in os.listdir(policy_dir):
    if file.endswith('.md'):
        print(f"- [{file}]({policy_dir}/{file})")
