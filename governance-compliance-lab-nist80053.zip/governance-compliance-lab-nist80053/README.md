# Governance & Compliance Lab – NIST 800-53

This project simulates a healthcare environment focused on governance and compliance practices based on the NIST 800-53 framework.
It includes control implementation documentation, sample policies, audit checklists, and an architecture diagram.

## Repository Structure

- `architecture/`: Governance architecture diagram
- `documentation/`: Implementation guides, audit checklist, templates
- `policies/`: Security policy documents
- `controls/`: NIST 800-53 control mappings
- `scripts/`: Supporting automation scripts

## Objective

To demonstrate how security analysts implement and document governance controls in line with regulatory frameworks.
